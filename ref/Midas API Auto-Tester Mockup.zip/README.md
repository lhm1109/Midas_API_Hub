
  # Midas API Auto-Tester Mockup

  This is a code bundle for Midas API Auto-Tester Mockup. The original project is available at https://www.figma.com/design/R2OSAgABATKEKMgANg8GRC/Midas-API-Auto-Tester-Mockup.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  